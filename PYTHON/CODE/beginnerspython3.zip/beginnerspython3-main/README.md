# beginnerspython3
Code repo for the Beginners Guide to Python 3 Programming

Each chapter is represented by a separate directory within the repo.

Chapters with exercieses have a sub directory containing sample solutions for the exerices in that chapter.
