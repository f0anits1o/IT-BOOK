#!/Library/Frameworks/Python.framework/Versions/3.7/bin/python3

print('Hello World')
print(5 * 4)
name = 'John'
print(name)
