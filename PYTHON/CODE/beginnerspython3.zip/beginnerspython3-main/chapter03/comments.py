# This is a comment
name = input('Enter your name: ')
# This is another comment
print(name)  # this is a comment the runs to the end of the line
