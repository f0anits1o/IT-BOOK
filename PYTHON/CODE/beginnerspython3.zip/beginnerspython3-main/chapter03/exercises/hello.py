print('Hello My Python World')
name = input('Please provide your name: ')
print('Hello ', name)
print(42 - 6)
