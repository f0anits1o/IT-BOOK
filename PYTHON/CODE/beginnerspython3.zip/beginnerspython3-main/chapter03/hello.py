# Print out a message and then ask the user for input

print('Hello, world')
user_name = input('Enter your name: ')
print('Hello ', user_name)
