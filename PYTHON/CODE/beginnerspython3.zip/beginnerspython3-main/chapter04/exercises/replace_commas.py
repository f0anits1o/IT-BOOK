original_string = 'John,Andrew,Smith,21,London,UK'
new_string = original_string.replace(',', ' ')
print(new_string)