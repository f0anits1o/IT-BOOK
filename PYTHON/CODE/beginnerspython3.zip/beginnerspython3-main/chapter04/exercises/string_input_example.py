original_string_1 = input('Please input first string')
original_string_2 = input('Please input the second string')
new_string = original_string_1 + ' ' + original_string_2
print(new_string)
print(len(new_string))
upper_case_string = new_string.upper()
print(upper_case_string)
print(new_string.find('Albus'))