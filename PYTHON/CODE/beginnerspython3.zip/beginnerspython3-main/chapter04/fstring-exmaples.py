# Example of using f-strings - introduced in Python 3.6
name = "Adam"
age = 22

message = f"Hello {name}, you are {age}"
print(message)
