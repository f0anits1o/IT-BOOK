# Python 3.9 added two new methods
# removeprefix() and removesuffix() methods

info = '-John Hunt*'
print(info)
print(info.removeprefix('-'))
print(info.removesuffix('*'))

