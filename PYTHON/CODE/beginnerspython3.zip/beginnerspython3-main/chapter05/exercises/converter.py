distance_in_km = int(input('Please input the distance in kilometers:'))
distance_in_miles = distance_in_km * 0.6214
print('The distance in miles is', distance_in_miles)