# Obtaining the type of an integer
var = 100
print(type(var))

# Obtaining the type of None
winner = None
print(type(winner))

# Testing a variable to see if it contains None
print(winner is None)
print(winner is not None)



