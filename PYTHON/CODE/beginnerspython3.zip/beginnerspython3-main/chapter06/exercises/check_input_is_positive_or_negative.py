num = int(input('Please input the distance in kilometers:'))

if num < 0:
    print('Number is negative')
elif num > 0:
    print('Number is positive')
else:
    print('Number is Zero')
