for i in range(1, 10, 2):
    print(i, ' ', end='' )

print()

for i in range(10, 1, -2):
    print(i, ' ', end='')
