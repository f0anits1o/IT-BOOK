count = 0
print('Starting')
while count < 10:
    print(count)
    count += 1

print('Done')

print('-' * 25)

fx = 0
x = 0

print('Starting')
while fx < 100:
    fx = 2 * x * (x + 1)
    print(x, '\t: ', fx)
    x += 1

print('Done')
