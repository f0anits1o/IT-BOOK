def recursive_function():
    print('calling recursive_function')
    recursive_function()


recursive_function()
