import module1

module1.f1()