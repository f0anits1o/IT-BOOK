import utils

print(utils.__name__)
print(utils.__doc__)
print(utils.__file__)

print(dir(utils))
