import utils

utils.printer(utils.default_shape)
shape = utils.Shape('circle')
utils.printer(shape)