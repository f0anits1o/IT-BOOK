import utils as utilities

utilities.printer(utilities.default_shape)
