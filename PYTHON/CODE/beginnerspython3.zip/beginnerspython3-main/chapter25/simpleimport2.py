from utils import Shape

s = Shape('rectangle')
print(s)
