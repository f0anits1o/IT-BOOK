from utils import *

printer(default_shape)
shape = Shape("circle")
printer(shape)