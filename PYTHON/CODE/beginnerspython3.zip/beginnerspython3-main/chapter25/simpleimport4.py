from utils import Shape, printer as myfunc

s = Shape('oval')
myfunc(s)
