class Shape:
    pass

class Printer:
    pass

class Processor:
        pass