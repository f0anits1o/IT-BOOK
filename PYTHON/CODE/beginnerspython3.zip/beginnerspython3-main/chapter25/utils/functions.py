"""This is the functions module"""

print('Welcome to the functions module')


def f1():
    print('f1[1]')


def f2():
    print('f2[1]')
