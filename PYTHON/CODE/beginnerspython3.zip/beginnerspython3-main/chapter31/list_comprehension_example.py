values = [1, 2, 4, 6, 8, 9]
print('values', values)

# List comprehension example
new_values = [i + 1 for i in values]
print('new_values', new_values)
